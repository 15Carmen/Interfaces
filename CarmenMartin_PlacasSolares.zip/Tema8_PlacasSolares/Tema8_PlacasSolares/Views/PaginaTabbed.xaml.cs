namespace Tema8_PlacasSolares.Views;

public partial class PaginaTabbed : TabbedPage
{
	public PaginaTabbed()
	{
		InitializeComponent();
	}
}